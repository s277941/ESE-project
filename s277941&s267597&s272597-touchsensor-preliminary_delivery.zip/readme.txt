In the Launchpad folder there are both the project schematic and the .brd board file. This last one is in the allegro folder.
In ORCAD_PERSONAL_LIBRARY there are all the padstacks, footprints, and the used .olb library.
